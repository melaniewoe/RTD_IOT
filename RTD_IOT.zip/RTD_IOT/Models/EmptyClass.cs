﻿using System;
namespace RTD_IOT.Models
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
