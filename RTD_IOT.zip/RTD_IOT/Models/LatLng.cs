﻿using System;
namespace RTD_IOT.Models
{
    public class LatLng
    {
        public float Lat { get; set; }
        public float Lng { get; set; }
        public string busline { get; set; }

    }
}
