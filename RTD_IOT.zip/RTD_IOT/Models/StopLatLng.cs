﻿using System;
namespace RTD_IOT.Models
{
    public class StopLatLng
    {
         public string stop_Lat { get; set; }
         public string stop_Lng { get; set; }
    }
}
